# Supply Brain — Time Cycle Diagnostic

Self-contained folder: dataset, script, README. Open the whole folder in
VS Code and you're ready to run.

## What this does

Checks whether the dataset shows a genuine, repeating business cycle —
before building any time-based (e.g. quarterly) segmentation on top of it.
Runs 6 independent checks and prints a clear verdict for each:

1. Revenue by month (realized $ from actual transactions)
2. Margin % by month (realized, not list-price based)
3. Units sold by month (pure volume, price stripped out)
4. `seasonal_flag` cross-check — do pre-tagged "seasonal" SKUs swing more?
5. Stockout rate by month — does supply pressure track the same shape?
6. 2025 actuals vs. 2026 forecast shape — partial recurrence check

## Folder structure

```
time_cycle_diagnostic/
├── time_cycle_diagnostic.py
├── data/                    <- the 14 raw v2 dataset CSV files
├── time_cycle_outputs/      <- results get written here
└── README.md
```

## Setup & run

```bash
pip install pandas numpy matplotlib
python time_cycle_diagnostic.py
```

No path editing needed — `DATA_DIR`/`OUTPUT_DIR` already point at the
bundled `data/`/`time_cycle_outputs/` folders.

## What it saves to `time_cycle_outputs/`

| File | Contents |
|---|---|
| `check_revenue_margin_monthly.csv` | Revenue and margin %, by month |
| `check_units_sold_monthly.csv` | Units sold, by month |
| `check_seasonal_flag_monthly.csv` | Revenue by month, split by `seasonal_flag` |
| `check_stockout_rate_monthly.csv` | Stockout rate, by month |
| `check_2025_vs_2026_shape.csv` | 2025 actual vs. 2026 forecast monthly shape |
| `time_cycle_summary_chart.png` | Revenue, units, and stockout rate overlaid, all indexed to their own yearly average so they're honestly comparable |
| `time_cycle_summary.txt` | Plain-text overall verdict — ready to paste into a slide or email |

## Important limitation (stated in the script's own output too)

Real transaction/actuals data (`orders.csv`, `demand_forecast.csv`'s
`in_sample` rows, `inventory.csv`) only covers **2025** in full — 2026
exists only as a forward-looking forecast, with no real actuals yet to
validate against. So this script can confirm a seasonal **shape within**
2025, but cannot fully confirm that shape **recurs** year over year —
that would need a second full year of real data. Check 6 is a partial
workaround (comparing 2025 actuals to 2026's *forecast* shape), which is
suggestive, not confirmed.

## Known finding, run against this dataset

Revenue, units sold, `seasonal_flag`, and stockout rate all point to the
same shape: quiet Jan–Jun, ramp from July, peak Sep–Oct, easing in
December. Margin % is essentially flat (only ~3 percentage points of
range across the year) and is **not** a useful cycle axis on its own —
worth flagging if anyone suggests using margin as a primary time-cycle
indicator.
